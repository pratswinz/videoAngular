# videoAngular
This project demonstrates video supports for cross browser,responsive and video controls  using angular js,jquery,javascript,bootstrap

Project Source : Building Custom HTML5 Video Playback with AngularJS(Lynda.com)

To Run the project:

Download project.
1 - Ad some videos to Video folder and accordingly change the names of those videos in data/playlist.json file.

2 - Run index.html file in browser
